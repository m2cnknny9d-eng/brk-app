import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Alle Gruppen mit Zugang für diesen Benutzer
    const userGroups = await prisma.userGroup.findMany({
      where: {
        userId: session.user.id,
      },
      include: {
        group: {
          select: {
            id: true,
            name: true,
            description: true,
            color: true,
            icon: true,
            isPublic: true,
            requiresAdmin: true,
          },
        },
      },
    })

    // Öffentliche Gruppen
    const publicGroups = await prisma.group.findMany({
      where: {
        isPublic: true,
        requiresAdmin: false,
      },
      select: {
        id: true,
        name: true,
        description: true,
        color: true,
        icon: true,
        isPublic: true,
        requiresAdmin: true,
      },
    })

    // Combine und dedupliziere
    const allGroups = [
      ...publicGroups,
      ...userGroups.map((ug) => ug.group),
    ]

    const uniqueGroups = Array.from(
      new Map(allGroups.map((g) => [g.id, g])).values()
    )

    // Admin sieht alle Gruppen
    if (session.user?.isAdmin) {
      const allGroupsForAdmin = await prisma.group.findMany({
        select: {
          id: true,
          name: true,
          description: true,
          color: true,
          icon: true,
          isPublic: true,
          requiresAdmin: true,
        },
      })
      return NextResponse.json({ groups: allGroupsForAdmin, isAdmin: true })
    }

    return NextResponse.json({ groups: uniqueGroups, isAdmin: false })
  } catch (error) {
    console.error('Groups API Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
