import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { inviteId } = await req.json()

    if (!inviteId) {
      return NextResponse.json(
        { error: 'Invite ID erforderlich' },
        { status: 400 }
      )
    }

    // Finde Invite
    const invite = await prisma.invite.findUnique({
      where: { id: inviteId },
      include: {
        group: true,
      },
    })

    if (!invite) {
      return NextResponse.json(
        { error: 'Einladung nicht gefunden' },
        { status: 404 }
      )
    }

    // Prüfe ob bereits verwendet
    if (invite.usedAt) {
      return NextResponse.json(
        { error: 'Einladung wurde bereits verwendet' },
        { status: 400 }
      )
    }

    // Prüfe ob abgelaufen
    if (new Date() > invite.expiresAt) {
      return NextResponse.json(
        { error: 'Einladung ist abgelaufen' },
        { status: 400 }
      )
    }

    // Prüfe ob Email stimmt
    if (invite.email !== session.user?.email) {
      return NextResponse.json(
        { error: 'Einladung ist für eine andere Email-Adresse' },
        { status: 403 }
      )
    }

    // Prüfe ob User bereits in Gruppe
    const existingGroup = await prisma.userGroup.findUnique({
      where: {
        userId_groupId: {
          userId: session.user.id,
          groupId: invite.groupId,
        },
      },
    })

    if (existingGroup) {
      return NextResponse.json(
        { error: 'Du hast bereits Zugang zu dieser Gruppe' },
        { status: 400 }
      )
    }

    // Markiere Invite als verwendet + füge zu Gruppe hinzu
    await prisma.invite.update({
      where: { id: inviteId },
      data: {
        usedBy: session.user.id,
        usedAt: new Date(),
      },
    })

    await prisma.userGroup.create({
      data: {
        userId: session.user.id,
        groupId: invite.groupId,
      },
    })

    return NextResponse.json({
      success: true,
      message: `Du bist jetzt Mitglied von ${invite.group.name}!`,
      group: {
        id: invite.group.id,
        name: invite.group.name,
      },
    })
  } catch (error) {
    console.error('Accept Invite Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
