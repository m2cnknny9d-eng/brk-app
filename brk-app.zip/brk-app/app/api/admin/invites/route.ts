import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

// GET: Liste aller Invites
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || !session.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    const invites = await prisma.invite.findMany({
      include: {
        group: {
          select: {
            id: true,
            name: true,
          },
        },
        user: {
          select: {
            id: true,
            email: true,
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json({ invites })
  } catch (error) {
    console.error('Get Invites Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST: Neue Invite erstellen
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || !session.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    const { email, groupId } = await req.json()

    if (!email || !groupId) {
      return NextResponse.json(
        { error: 'Email und GroupId erforderlich' },
        { status: 400 }
      )
    }

    // Prüfe, ob Gruppe existiert
    const group = await prisma.group.findUnique({
      where: { id: groupId },
    })

    if (!group) {
      return NextResponse.json(
        { error: 'Gruppe nicht gefunden' },
        { status: 404 }
      )
    }

    // Prüfe ob Invite schon existiert
    const existingInvite = await prisma.invite.findFirst({
      where: {
        email,
        groupId,
        usedAt: null,
      },
    })

    if (existingInvite) {
      return NextResponse.json(
        { error: 'Invite für diese Email existiert bereits' },
        { status: 400 }
      )
    }

    // Erstelle neue Invite (gültig 30 Tage)
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 30)

    const invite = await prisma.invite.create({
      data: {
        email,
        groupId,
        invitedBy: session.user.id,
        expiresAt,
      },
      include: {
        group: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    })

    return NextResponse.json({
      success: true,
      invite,
      message: `Einladung an ${email} für ${group.name} erstellt`,
    })
  } catch (error) {
    console.error('Create Invite Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
