import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || !session.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    const invite = await prisma.invite.findUnique({
      where: { id: params.id },
    })

    if (!invite) {
      return NextResponse.json(
        { error: 'Invite nicht gefunden' },
        { status: 404 }
      )
    }

    // Nur ungenutzte Invites löschen
    if (invite.usedAt) {
      return NextResponse.json(
        { error: 'Nur ungenutzte Invites können gelöscht werden' },
        { status: 400 }
      )
    }

    await prisma.invite.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete Invite Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
