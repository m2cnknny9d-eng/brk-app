import Link from 'next/link'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { Heart, Shield, Calendar, Award } from 'lucide-react'

export default async function Home() {
  const session = await getServerSession(authOptions)

  if (session) {
    redirect('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-brk-red via-red-500 to-red-600 flex flex-col">
      {/* Navigation */}
      <nav className="flex items-center justify-between p-6 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <Heart className="w-8 h-8 text-white" fill="white" />
          <div className="text-2xl font-bold text-white">BRK Bayern</div>
        </div>
        <div className="space-x-4">
          <Link href="/auth/login">
            <button className="px-6 py-2 rounded-lg text-brk-red bg-white hover:bg-gray-100 font-semibold transition-colors">
              Anmelden
            </button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="flex-1 max-w-7xl mx-auto px-6 py-20 flex flex-col justify-center w-full">
        <h1 className="text-6xl font-bold text-white mb-6">
          Dein Ehrenamts-Dashboard
        </h1>
        <p className="text-xl text-white/90 mb-12 max-w-2xl">
          Verwalte deine Lehrgänge, Fortbildungen und Nachweise übersichtlich in einer modernen App - speziell für BRK Bayern entwickelt
        </p>

        <div className="flex gap-4 mb-20">
          <Link href="/auth/login">
            <button className="px-8 py-4 rounded-xl bg-white text-brk-red hover:bg-gray-100 font-bold text-lg transition-colors shadow-lg">
              Jetzt anmelden
            </button>
          </Link>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <FeatureCard
            icon={<Calendar className="w-8 h-8" />}
            title="Lehrgangsübersicht"
            description="Sehe auf einen Blick, welche Kurse du benötigst und wann sie ablaufen"
          />
          <FeatureCard
            icon={<Award className="w-8 h-8" />}
            title="Nachweise verwalten"
            description="Behalte deine Zertifikate im Blick - mit Ablaufdaten und Erinnerungen"
          />
          <FeatureCard
            icon={<Shield className="w-8 h-8" />}
            title="Für BRK Bayern"
            description="Speziell entwickelt für die Bereitschaften des BRK Bayern"
          />
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-white/80 border-t border-white/20">
        <p>© 2024 BRK Bayern Ehrenamtsapp. Entwickelt mit ❤️</p>
      </div>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="bg-white/10 backdrop-blur rounded-2xl p-6 text-white hover:bg-white/20 transition-colors">
      <div className="mb-4 text-brk-lightred">{icon}</div>
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-white/70">{description}</p>
    </div>
  )
}
