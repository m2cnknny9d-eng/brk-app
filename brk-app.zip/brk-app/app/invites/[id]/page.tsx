'use client'

import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Heart, CheckCircle, AlertCircle } from 'lucide-react'

export default function AcceptInvitePage({
  params,
}: {
  params: { id: string }
}) {
  const router = useRouter()
  const { data: session, status } = useSession()
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  // Redirect if not authenticated
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/login')
    }
  }, [status, router])

  // Auto-accept on load
  useEffect(() => {
    if (session?.user?.id && params.id) {
      acceptInvite()
    }
  }, [session?.user?.id, params.id])

  const acceptInvite = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/invites/accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inviteId: params.id }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(true)
        // Redirect nach 2 Sekunden
        setTimeout(() => {
          router.push('/dashboard')
        }, 2000)
      } else {
        setError(data.error || 'Fehler beim Akzeptieren der Einladung')
      }
    } catch (err) {
      setError('Ein Fehler ist aufgetreten')
    } finally {
      setIsLoading(false)
    }
  }

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-brk-red to-red-600 flex items-center justify-center">
        <div className="animate-pulse">
          <Heart className="w-12 h-12 text-white" fill="currentColor" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-brk-red to-red-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl p-8 text-center">
          {success ? (
            <>
              <div className="mb-6 flex justify-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Willkommen! 🎉
              </h1>
              <p className="text-gray-600 mb-6">
                Du wurdest erfolgreich zur Gruppe hinzugefügt. Du wirst gleich zum Dashboard weitergeleitet...
              </p>
            </>
          ) : error ? (
            <>
              <div className="mb-6 flex justify-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <AlertCircle className="w-8 h-8 text-red-600" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Fehler
              </h1>
              <p className="text-gray-600 mb-6">{error}</p>
              <button
                onClick={() => router.push('/dashboard')}
                className="px-6 py-3 bg-brk-red text-white rounded-xl font-semibold hover:bg-brk-darkred transition-colors"
              >
                Zum Dashboard
              </button>
            </>
          ) : null}
        </div>
      </div>
    </div>
  )
}
